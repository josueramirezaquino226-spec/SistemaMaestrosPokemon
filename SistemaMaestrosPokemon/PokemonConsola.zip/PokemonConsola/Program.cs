using PokemonConsola;
using Microsoft.EntityFrameworkCore;
using System.Text;

Console.OutputEncoding = Encoding.UTF8;

using (var db = new AppDbContext())
    db.Database.EnsureCreated();

while (true)
{
    Console.WriteLine("\n=== SISTEMA DE MAESTROS POKÉMON ===");
    Console.WriteLine("1. Registrar maestro Pokémon");
    Console.WriteLine("2. Agregar Pokémon a un maestro");
    Console.WriteLine("3. Listar maestros");
    Console.WriteLine("4. Exportar informe HTML");
    Console.WriteLine("0. Salir");
    Console.Write("Selecciona una opción: ");
    string? opcion = Console.ReadLine();

    try
    {
        using var db = new AppDbContext();

        switch (opcion)
        {
            case "1":
                Console.Write("Código: "); string codigo = LeerTexto();
                Console.Write("Nombre: "); string nombre = LeerTexto();
                Console.Write("Ciudad: "); string ciudad = LeerTexto();
                Console.Write("Teléfono: "); string telefono = LeerTexto();
                Console.Write("Correo: "); string correo = LeerTexto();
                db.Maestros.Add(new MaestroPokemon
                {
                    Codigo = codigo, Nombre = nombre, Ciudad = ciudad,
                    Telefono = telefono, Correo = correo
                });
                db.SaveChanges();
                Console.WriteLine("Maestro registrado correctamente.");
                break;

            case "2":
                Console.Write("Código del maestro: "); string cod = LeerTexto();
                var maestro = db.Maestros.Include(m => m.Pokemones)
                    .FirstOrDefault(m => m.Codigo == cod);
                if (maestro == null) { Console.WriteLine("No existe ese maestro."); break; }
                Console.Write("Nombre del Pokémon: "); string pn = LeerTexto();
                Console.Write("Color: "); string color = LeerTexto();
                Console.Write("Tipo: "); string tipo = LeerTexto();
                Console.Write("Latitud: ");
                if (!double.TryParse(Console.ReadLine(), System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double lat))
                { Console.WriteLine("Latitud inválida. Usa punto decimal, por ejemplo 19.4326."); break; }
                Console.Write("Longitud: ");
                if (!double.TryParse(Console.ReadLine(), System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double lon))
                { Console.WriteLine("Longitud inválida. Usa punto decimal, por ejemplo -70.1234."); break; }
                maestro.Pokemones.Add(new Pokemon { Nombre = pn, Color = color, Tipo = tipo, Latitud = lat, Longitud = lon });
                db.SaveChanges();
                Console.WriteLine("Pokémon agregado correctamente.");
                break;

            case "3":
                var maestros = db.Maestros.Include(m => m.Pokemones).OrderBy(m => m.Codigo).ToList();
                if (maestros.Count == 0) Console.WriteLine("No hay maestros registrados.");
                foreach (var m in maestros)
                    Console.WriteLine($"{m.Codigo} | {m.Nombre} | {m.Ciudad} | Pokémon: {m.Pokemones.Count}");
                break;

            case "4":
                var lista = db.Maestros.OrderBy(m => m.Codigo).ToList();
                if (lista.Count == 0) { Console.WriteLine("No hay maestros para exportar."); break; }
                foreach (var m in lista) Console.WriteLine($"{m.Codigo} - {m.Nombre}");
                Console.Write("Código del maestro para el informe: "); string elegido = LeerTexto();
                var seleccionado = db.Maestros.Include(m => m.Pokemones).FirstOrDefault(m => m.Codigo == elegido);
                if (seleccionado == null) { Console.WriteLine("No existe ese maestro."); break; }
                string Esc(string? s) => System.Net.WebUtility.HtmlEncode(s ?? "");
                var sb = new StringBuilder();
                sb.AppendLine("<!DOCTYPE html><html lang='es'><head><meta charset='UTF-8'><title>Informe Pokémon</title>");
                sb.AppendLine("<style>body{font-family:Arial;margin:35px;color:#222}h1{color:#2457a7}table{border-collapse:collapse;width:100%}th,td{border:1px solid #bbb;padding:8px;text-align:left}th{background:#e8eef8}</style></head><body>");
                sb.AppendLine($"<h1>Informe del maestro Pokémon: {Esc(seleccionado.Nombre)}</h1>");
                sb.AppendLine("<h2>Datos del maestro</h2><ul>");
                sb.AppendLine($"<li><b>Código:</b> {Esc(seleccionado.Codigo)}</li><li><b>Nombre:</b> {Esc(seleccionado.Nombre)}</li><li><b>Ciudad:</b> {Esc(seleccionado.Ciudad)}</li><li><b>Teléfono:</b> {Esc(seleccionado.Telefono)}</li><li><b>Correo:</b> {Esc(seleccionado.Correo)}</li></ul>");
                sb.AppendLine("<h2>Pokémon registrados</h2><table><tr><th>Nombre</th><th>Color</th><th>Tipo</th><th>Latitud</th><th>Longitud</th></tr>");
                foreach (var p in seleccionado.Pokemones)
                    sb.AppendLine($"<tr><td>{Esc(p.Nombre)}</td><td>{Esc(p.Color)}</td><td>{Esc(p.Tipo)}</td><td>{p.Latitud}</td><td>{p.Longitud}</td></tr>");
                sb.AppendLine("</table></body></html>");
                string archivo = $"Informe_{seleccionado.Codigo}.html";
                File.WriteAllText(archivo, sb.ToString(), Encoding.UTF8);
                Console.WriteLine($"Informe creado: {Path.GetFullPath(archivo)}");
                break;

            case "0": return;
            default: Console.WriteLine("Opción no válida."); break;
        }
    }
    catch (DbUpdateException)
    {
        Console.WriteLine("No se pudo guardar. Verifica que el código del maestro no esté repetido.");
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Ocurrió un error: {ex.Message}");
    }
}

static string LeerTexto() => Console.ReadLine()?.Trim() ?? "";
