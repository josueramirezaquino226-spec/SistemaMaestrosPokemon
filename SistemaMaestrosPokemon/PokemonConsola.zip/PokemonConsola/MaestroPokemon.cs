using System.Collections.Generic;

namespace PokemonConsola;

public class MaestroPokemon
{
    public int Id { get; set; }
    public string Codigo { get; set; } = "";
    public string Nombre { get; set; } = "";
    public string Ciudad { get; set; } = "";
    public string Telefono { get; set; } = "";
    public string Correo { get; set; } = "";
    public List<Pokemon> Pokemones { get; set; } = new();
}
