using Microsoft.EntityFrameworkCore;

namespace PokemonConsola;

public class AppDbContext : DbContext
{
    public DbSet<MaestroPokemon> Maestros => Set<MaestroPokemon>();
    public DbSet<Pokemon> Pokemones => Set<Pokemon>();

    protected override void OnConfiguring(DbContextOptionsBuilder options)
    {
        options.UseSqlite("Data Source=pokemon.db");
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<MaestroPokemon>()
            .HasIndex(m => m.Codigo)
            .IsUnique();

        modelBuilder.Entity<MaestroPokemon>()
            .HasMany(m => m.Pokemones)
            .WithOne(p => p.MaestroPokemon)
            .HasForeignKey(p => p.MaestroPokemonId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}
