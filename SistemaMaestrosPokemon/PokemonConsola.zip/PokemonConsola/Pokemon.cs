namespace PokemonConsola;

public class Pokemon
{
    public int Id { get; set; }
    public string Nombre { get; set; } = "";
    public string Color { get; set; } = "";
    public string Tipo { get; set; } = "";
    public double Latitud { get; set; }
    public double Longitud { get; set; }

    public int MaestroPokemonId { get; set; }
    public MaestroPokemon? MaestroPokemon { get; set; }
}
